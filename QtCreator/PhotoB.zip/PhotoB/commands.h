#ifndef COMMANDS_H
#define COMMANDS_H

#define PROPCASE_COMMAND "return require('propcase')"

#endif // COMMANDS_H
