--[[
@title file browser test
]]

f = file_browser("A/CHDK/SCRIPTS")

print(f)
