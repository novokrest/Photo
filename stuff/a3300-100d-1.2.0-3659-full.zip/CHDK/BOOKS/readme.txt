nothing in here yet.

insert tutorials and links to tutorials (ubasic, raw average, etc)